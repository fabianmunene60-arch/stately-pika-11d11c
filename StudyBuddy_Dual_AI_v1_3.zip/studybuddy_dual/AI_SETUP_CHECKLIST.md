# StudyBuddy AI setup checklist

## What is already wired in this project
- The website includes a student AI chat interface.
- The browser sends chat messages to `/api/ask`; it does not call AI providers directly.
- The server routes requests to OpenAI or Claude, and can fall back to the other configured provider.
- The UI displays which provider answered and which providers are configured.
- The assignment-help flow can send a paid question to the same AI gateway after payment verification.

## Configure the AI engines
1. Copy `.env.example` to `.env`.
2. Add `OPENAI_API_KEY` from https://platform.openai.com/api-keys.
3. Add `ANTHROPIC_API_KEY` from https://console.anthropic.com/settings/keys.
4. Keep `AI_DEFAULT_PROVIDER=openai` and `AI_FALLBACK_ENABLED=true` to use OpenAI first and Claude as fallback.
5. Confirm the model IDs are enabled for your accounts. The sample defaults are configurable.
6. Run `npm install`, then `npm start`.
7. Visit `/api/ai/status` and confirm both providers show `true`.
8. Open the site, ask the tutor a question, then select each provider in turn and test it.

## Important security rules
- Never put provider keys in `public/index.html`, frontend JavaScript, a mobile app bundle, or a public Git repository.
- Use environment variables locally and your hosting provider's secret/environment-variable settings in production.
- Set provider spending limits/alerts and application rate limits before inviting students.
- Do not collect or send unnecessary personal student data to either provider.

## Hosting note
This is an Express/Node project. Deploy the complete project to a Node.js host that runs `npm start`; uploading only the static `public` folder to a static host will not run the AI gateway. The browser must reach this server's `/api/ask` and `/api/ai/status` endpoints.

## Payments
AI chat can be tested without Paystack configured. To use paid assignment checkout, configure `PAYSTACK_SECRET_KEY` and `PUBLIC_BASE_URL`, and test with Paystack test credentials first.
